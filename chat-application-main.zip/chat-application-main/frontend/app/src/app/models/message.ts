export class Message {
    senderEmail: string;
    time: string;
    replymessage: string;

    constructor() {

    }
}
