# chat-application
Full frontend and backend ( Angular , Spring Boot and mongoDb )

Steps to run the application
=============================
In backend
Step1: Add the chat-service to the worspace using intellij , sts , etc(depends on your choice).   
Step2: Change the configuation in application.properties according to your system.             
Step3: Run the backend.                                                         
                                                                              
In frontend                                                                    
Step4: Open the app in vs code.                                                        
Step5: Install npm using command : npm install                                                                                 
Step6: Run the application using command : ng serve
Step7: Open any web browser                                                                                                                                       
   type : localhost:4200

=============IMPORTANT================                                                                                                    
Full frontend and backend ( Angular , Spring Boot and MYSQL ) added in another branch                                                                    
(change mysql username and password in configuration file)                                                                                    
                                                                                                                                     
To pull from that branch use the command :-                                                                                                                   
git clone --branch chat_using_mysql https://github.com/codreal-yt/chat-application.git                                                                     
                                                                                                                                                  
(If getting any error, Ping me in Youtube channel comment box)                                                                                             

======================================

Like, share and subscribe to my channel for more updates.                                    
https://www.youtube.com/@codreal       
                                                                                             
Thank You
