package com.codreal.chatservice.exceptions;

public class ChatAlreadyExistException extends Throwable {
}
