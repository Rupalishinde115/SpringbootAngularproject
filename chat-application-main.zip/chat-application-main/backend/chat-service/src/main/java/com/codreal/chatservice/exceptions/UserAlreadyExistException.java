package com.codreal.chatservice.exceptions;

public class UserAlreadyExistException extends Throwable {
}
