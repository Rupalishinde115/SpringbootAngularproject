package com.codreal.chatservice.exceptions;

public class NoChatExistsInTheRepository extends Throwable {
}
